import React from 'react';
import { Code2, Cpu, Globe2, ArrowRight } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen relative">
      {/* Background Image */}
      <div 
        className="absolute inset-0 w-full h-full bg-cover bg-center bg-no-repeat"
        style={{ 
          backgroundImage: "url('/assets/images.jfif')",
          backgroundSize: 'cover',
          filter: 'brightness(0.7)'
        }}
      />
      
      {/* Overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-gray-900/80 to-gray-900/95" />

      {/* Navigation */}
      <nav className="relative z-20 w-full">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-20">
            <div className="flex items-center space-x-3">
              <img 
                src="/assets/artificial-intelligence-ai-processor-chip-icon-symbol-for-graphic-design-logo-website-social-media-mobile-app-ui-illustration-vector.jpg" 
                alt="Rogue AI Logo" 
                className="h-10 w-10 object-contain"
              />
              <span className="text-2xl font-bold text-white">Rogue AI</span>
            </div>
          </div>
        </div>
      </nav>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16 text-center lg:text-left">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center px-4 py-2 bg-gray-800/50 rounded-full border border-gray-700 backdrop-blur-sm">
              <Code2 className="w-4 h-4 text-blue-400 mr-2" />
              <span className="text-gray-300 text-sm">AI-Powered Solutions</span>
            </div>
            
            <h1 className="text-5xl lg:text-6xl font-bold text-white leading-tight">
              Transforming Future with{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
                Artificial Intelligence
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 max-w-2xl">
              Harness the power of advanced AI technology to revolutionize your business. 
              Create smarter solutions for tomorrow's challenges.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button className="px-8 py-4 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-semibold flex items-center justify-center transition-all backdrop-blur-sm">
                Get Started
                <ArrowRight className="ml-2 w-5 h-5" />
              </button>
              <button className="px-8 py-4 bg-gray-800/50 hover:bg-gray-700/50 text-white rounded-lg font-semibold border border-gray-700 transition-all backdrop-blur-sm">
                Learn More
              </button>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-3xl blur-3xl"></div>
            <div className="relative bg-gray-800/50 border border-gray-700 rounded-3xl p-8 backdrop-blur-sm">
              <div className="grid grid-cols-2 gap-6">
                {[
                  {
                    icon: <Globe2 className="w-8 h-8 text-cyan-400" />,
                    title: "Global AI Network",
                    desc: "Worldwide deployment"
                  },
                  {
                    icon: <Cpu className="w-8 h-8 text-blue-400" />,
                    title: "Neural Processing",
                    desc: "Advanced algorithms"
                  }
                ].map((item, index) => (
                  <div key={index} className="bg-gray-900/50 p-6 rounded-2xl border border-gray-700 backdrop-blur-sm">
                    {item.icon}
                    <h3 className="text-white font-semibold mt-4">{item.title}</h3>
                    <p className="text-gray-300 text-sm mt-1">{item.desc}</p>
                  </div>
                ))}
              </div>
              <div className="mt-6 bg-gray-900/50 p-6 rounded-2xl border border-gray-700 backdrop-blur-sm">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h3 className="text-white font-semibold">AI Performance</h3>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-cyan-400"></div>
                      <p className="text-gray-300 text-sm">Real-time Analysis</p>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-white">99.9%</div>
                </div>
                <div className="mt-4 bg-gray-800/50 rounded-full h-2">
                  <div className="w-[90%] h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;